
const profile={
    username: "@shradhakhapra",
    isFollow: false,
    followers: 123,
    following: 123,

};
console.log(typeof profile["isFollow"]);